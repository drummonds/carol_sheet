\header {
	filename = "SilentNight-Complete.ly"
	enteredby = "Gordon Gilbert"
	composer = "Franz Gruber, 1818"
	poet = "Rev. Joseph Mohr, 1818"
	date="trans 1863 by Jane Campbell"
	title = "Silent Night"
	metre = "Silent Night P.M."
	meter = \metre
	copyright = "Public Domain"
	style = "Hymn"
	mutopiacomposer = \composer
	mutopiapoet=\poet
	maintainer = "Gordon Gilbert"
	maintainerEmail = "gord@angel.eicat.ca"
	lastupdated = "2005/Dec/08"
}

\version "2.15.19"

\paper {
	#(set-paper-size "letter")
	% ragged-bottom=##f
	% ragged-last-bottom=##f
}
global= {

	\time 6/8
    \key bes \major
   
    % \partial 4
   % \skip 1 * 20 \bar "||"
    
}

sop = \context Voice = "sop"    {
	\voiceOne
	f'8.( g'16) f'8 d'4. \bar "||"
	f'8.( g'16) f'8 d'4. \bar "||"
	c''4 c''8 a'4. bes'4 bes'8 f'4. \bar "||"
	g'4 g'8 bes'( a') g'f'8. g'16 f'8 d'4. \bar "||"
	g'4 g'8 bes' a' g' f'8. g'16 f'8 d'4. \bar "||"
	c''4 c''8 ees''8.( c''16) a'8 bes'4.( d'') \bar "||"
	bes'8( f') d' f'8.( ees'16) c'8 bes4. ~ bes \bar "||"
}

alto=\context Voice = "alto"   {
	\voiceTwo
	d'8. ees'16 d'8 bes4.
	d'8. ees'16 d'8 bes4.
	ees'4 ees'8 ees'4. d'4 d'8 d'4.
	ees'4 ees'8 g'( f') ees' d'8. ees'16 d'8 bes4.
	bes4 ees'8 g' f' ees' d'8. ees'16 d'8 bes4.
	ees'4 ees'8 ees'8.( ees'16) ees'8 d'4.( f')
	d'4 bes8 d'8.( c'16) a8 bes4. ~ bes
}	
	
tenor = \context Voice = "tenor"   {
	\voiceOne
	f4 f8 bes4.
	f4 f8 bes4. 
	a4 a8 c'4. bes4 bes8 bes4.
	bes4 bes8 bes( bes) bes bes8.( bes16) bes8 f4.
	ees4 bes8 g a bes bes4 bes8 f4.
	a4 a8 c'8.( a16) c'8 bes4.( f)
	f4 f8 a8.( f16) ees8 d4. ~ d
}
	
bass = \context Voice = "bass"   {
	\voiceTwo
	bes,4 bes,8 bes,4.
	bes,4 bes,8 bes,4.
	f4 f8 f4. bes,4 bes,8 bes,4.
	ees4 ees8( ees) ees ees bes8.(bes16) bes8 f4.
	ees4 ees8 ees f g bes4 bes8 bes,4.
	f4 f8 f8.( f16) f8 bes,4.( bes,)
	bes,4 bes,8 f,8.( f,16) f,8 bes,4. ~ bes,
}
accomp=\chordmode {
 
}



stanzaa = \lyricmode {
	Si -- lent night! Ho -- ly night!
	All is calm, all is bright.
	Round yon Vir -- gin Mo -- ther and Child
	Ho -- ly In -- fant so ten -- der and mild,
	Sleep in heaven -- ly peace,
	Sleep in heaven -- ly peace.
}

stanzab = \lyricmode {
	Si -- lent night! Ho -- ly night!
	On -- ly for shep -- herds' sight
	Came blest vis -- ions of an -- gel throngs,
	With their loud al -- le -- lu -- i -- a songs,
	Say -- ing Christ is come,
	Say -- ing Christ is come.
}

stanzac = \lyricmode {
	Si -- lent night! Ho -- ly night!
	Child of heaven, O how bright
	Thou didst smile on us when thou wast born,
	Blest in -- deed was that hap -- py morn,
	Full of heaven -- ly joy,
	Full of heaven -- ly joy.
}

stanzad = \lyricmode {
	
}
stanzae = \lyricmode {
	
}
stanzaf = \lyricmode {
	
}

\score {
	   \context ChoirStaff <<
	       \context ChordNames \accomp
		 \unset ChoirStaff.melismaBusyProperties 
		\context Staff ="upper"  { \clef "G" <<
			\global
			\sop
			\alto
		>>}
       		
		\lyricsto "sop" \context Lyrics = "stanza-1" {
			\set stanza = "1."
				\stanzaa }
		\lyricsto "sop" \context Lyrics = "stanza-2" {
			\set stanza = "2."
				\stanzab }
		\lyricsto "sop" \context Lyrics = "stanza-3" {
			\set stanza = "3."
				\stanzac }
	%	\lyricsto "sop" \context Lyrics = "stanza-4" {
	%		\set stanza = "4."
	%			\stanzad }
	%	\lyricsto "sop" \context Lyrics = "stanza-5" {
	%		\set stanza = "5."
	%			\stanzae }
	%	\lyricsto "sop" \context Lyrics = "stanza-6" {
	%		\set stanza = "6."
	%			\stanzaf }
		\context Staff = "lower"  { \clef "F"<<
			\global
			\tenor
			\bass
		>>}
	>>
	\layout{
		indent = 0.0\pt
		\context {
			\ChordNames
			\override ChordName  #'style = #'american
			chordChanges = ##t
		    }
	}
	
  \midi {
    \context {
      \Score
      tempoWholesPerMinute = #(ly:make-moment 120 4)
      }
    }


}


\header {
	filename = "WhileShepherdsWatched-Complete.ly"
	enteredby = "Gordon Gilbert"
	composer = "Est's Psalmes, 1592"
	poet = "Nahum Tate, 1700"
	date="1751"
	title = "While Shepherds Watched"
	metre = "Winchester Old C.M."
	meter = \metre
	copyright = "Public Domain"
	style = "Hymn"
	mutopiacomposer = \composer
	mutopiapoet=\poet
	maintainer = "Gordon Gilbert"
	maintainerEmail = "gord@angel.eicat.ca"
	lastupdated = "2005/Dec/08"
}

\version "2.15.19"

\paper {
	#(set-paper-size "letter")
	obsolete-between-system-padding = #1  system-system-spacing #'padding = #(/ obsolete-between-system-padding staff-space)  score-system-spacing #'padding = #(/ obsolete-between-system-padding staff-space)
	% ragged-bottom=##f
	% ragged-last-bottom=##f
}
global= {

	\time 4/4
    \key f \major
   
    \partial 4
   % \skip 1 * 20 \bar "||"
    
}

sop = \context Voice = "sop"    {
	\voiceOne
	f'4 a'4. a'8 g'4 f' bes' bes' a' \bar "||"
	g' \bar "|" a' c'' c'' b' c''2. \bar "||"
	a'4 \bar "|" d''4. c''8 bes'4 a' g' f' e' \bar "||"
	a' \bar "|" g' f' f' e' f'2. \bar "||"

}

alto=\context Voice = "alto"   {
	\voiceTwo
	c'4 f'4. f'8 e'4 d' d' f' f' 
	e' f' g' g' g' e'2.
	f'4 f'4. f'8 f'4 f' e' d' cis'
	c' e' d' d' c' c'2.
}	
	
tenor = \context Voice = "tenor"   {
	\voiceOne
	a4 c'4. c'8 c'4 a bes d' c' 
	c' c' c' d' d' c'2.
	c'4 bes4. a8 bes4 c' c' a a 
	a c' a bes g a2.
}
	
bass = \context Voice = "bass"   {
	\voiceTwo
	f4 f4. f8 c4 d bes, bes, f
	e f e g g c2.
	f4 bes4. f8 d4 f c d a,
	f c d bes, c f2.
}

accomp=\chordmode {
 
}



stanzaa = \lyricmode {
	While she -- pherds watched their flocks by night,
	All seat -- ed on the ground,
	The an -- gel of the Lord came down,
	And glo -- ry shone a -- round.
}

stanzab = \lyricmode {
	'Fear not,' said he for migh -- ty dread
	Had siezed their trou -- bled mind;
	'Glad ti -- dings of great joy I bring
	To you and all man -- kind.
}

stanzac = \lyricmode {
	'To you, in Da -- vid's town, this day
	Is born of Da -- vid's line
	A Sav -- iour, who is Christ the Lord;
	And this shall be the sign:
}

stanzad = \lyricmode {
	'The heaven -- ly Babe you there shall find
	To hu -- man view dis -- played,
	All mean -- ly wrapped in swa -- thing bands,
	And in a man -- ger laid.'
}
stanzae = \lyricmode {
	Thus spake the ser -- aph; and forth -- with
	Ap -- peared a shin -- ing throng
	Of an -- gels, prai -- sing God, who thus
	Ad -- dressed their joy -- ful song:
}

stanzaf = \lyricmode {
	'All glo -- ry be to God on high,
	And to the earth be peace;
	Good will hence -- forth from heaven to men
	Be -- gin, and ne -- ver cease!'
}

\score {
	   \context ChoirStaff <<
	       \context ChordNames \accomp
		 \unset ChoirStaff.melismaBusyProperties 
		\context Staff ="upper"  { \clef "G" <<
			\global
			\sop
			\alto
		>>}
       		
		\lyricsto "sop" \context Lyrics = "stanza-1" {
			\set stanza = "1."
				\stanzaa }
		\lyricsto "sop" \context Lyrics = "stanza-2" {
			\set stanza = "2."
				\stanzab }
		\lyricsto "sop" \context Lyrics = "stanza-3" {
			\set stanza = "3."
				\stanzac }
		\lyricsto "sop" \context Lyrics = "stanza-4" {
			\set stanza = "4."
				\stanzad }
		\lyricsto "sop" \context Lyrics = "stanza-5" {
			\set stanza = "5."
				\stanzae }
		\lyricsto "sop" \context Lyrics = "stanza-6" {
			\set stanza = "6."
				\stanzaf }
		\context Staff = "lower"  { \clef "F"<<
			\global
			\tenor
			\bass
		>>}
	>>
	\layout{
		indent = 0.0\pt
		\context {
			\ChordNames
			\override ChordName  #'style = #'american
			chordChanges = ##t
		    }
	}
	
  \midi {
    \context {
      \Score
      tempoWholesPerMinute = #(ly:make-moment 120 4)
      }
    }


}


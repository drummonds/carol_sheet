\header {
	filename = "OnceInRoyal-Complete.ly"
	enteredby = "Gordon Gilbert"
	composer = "H.J. Gauntlett, 1858"
	poet = "Cecil Frances Alexander, 1848"
	date=""
	title = "Once In Royal David's City"
	metre = "Irby 87.87.77."
	meter = \metre
	copyright = "Public Domain"
	style = "Hymn"
	mutopiacomposer = \composer
	mutopiapoet=\poet
	maintainer = "Gordon Gilbert"
	maintainerEmail = "gord@angel.eicat.ca"
	lastupdated = "2005/Dec/10"
}

\version "2.15.19"

\paper {
	#(set-paper-size "letter")
	% ragged-bottom=##f
	% ragged-last-bottom=##f
}
global= {

	\time 4/4
    \key f \major
    #(set-global-staff-size 17)
   %\set Staff.minimumVerticalExtent = #'(-4 . 4)
     \partial 2
   % \skip 1 * 20 \bar "||"
    
}

sop = \context Voice = "sop"    {
	\voiceOne
	c'4 e' f'4. f'8 f'( e') f'( g') g'4 f' \bar "||"
	f' a' c''4. a'8 a'( g') f'( e') f'2 \bar "||"
	c'4 e' f'4. f'8 f'( e') f'( g') g'4 f' \bar "||"
	f' a' c''4. a'8 a'( g') f'( e') f'2 \bar "||"
	d''4 d'' c''4. f'8 bes'4 bes' a'2 \bar "||"
	d''4 d'' c''4. a'8 a'( g') f'( e') f'2 \bar "||"
}

alto=\context Voice = "alto"   {
	\voiceTwo
	c'4 bes c'4. c'8 c'4 c' c' c' 
	c' d' c'4. f'8 d'4 c' c'2 
	c'4 bes c'4. c'8 c'4 c' c' c' 
	c' d' c'4. f'8 d'4 c' c'2 
	f'4 f' f'8 e' f' f' f'4 e' f'2
	f'4 f' c'8 e' f' f' d'4 c' c'2
}	
	
tenor = \context Voice = "tenor"   {
	\voiceOne
	a4 g f4. a8 a g a bes bes4 a 
	a f f4. c'8 c' bes a g a2 
	a4 g f4. a8 a g a bes bes4 a 
	a f f4. c'8 c' bes a g a2 
	bes4 bes a8 bes c' a d'4 c' c'2
	bes4 bes bes8 g a c' c' bes a g a2
}
	
bass = \context Voice = "bass"   {
	\voiceTwo
	f,4 g, a,4. f,8 c4 c f f 
	f d a,4. a,8 bes,4 c f2
	f,4 g, a,4. f,8 c4 c f f 
	f d a,4. a,8 bes,4 c f2
	bes,8 c d e f g a f g4 c f2
	bes,8 c d e f4. a,8 bes,4 c f,2
}
accomp=\chordmode {
 
}
stanzaa = \lyricmode {
	Once in roy -- al Da -- vid's ci -- ty
	Stood a low -- ly cat -- tle shed,
	Where a mo -- ther laid her ba -- by
	In a man -- ger for His bed:
	Ma -- ry was that mo -- ther mild
	Je -- sus Christ her lit -- tle Child.
}

stanzab = \lyricmode {
	He came down to earth from hea -- ven
	Who is God and Lord of all,
	And His shel -- ter was a sta -- ble
	And his cra -- dle was a stall;
	With the poor, and mean, and low-ly
	Lived on earth our Sav -- iour holy.
}
stanzac = \lyricmode {
	And, through all His won -- drous child -- hood
	He would hon -- our and o -- bey,
	Love, and watch the low -- ly mai -- den
	In whose gen -- tle arms He lay:
	Christ -- ian child -- ren all must be
	Mild, O -- bed -- ient, good as He.
}	
stanzad = \lyricmode {
	For He is our child -- hood's pat -- tern,
	Day by day like us He grew;
	He was lit -- tle, weak, and help -- less,
	Tears and smiles like us He knew;
	And He feel -- eth for our sad-ness,
	And He shar -- eth in our glad-ness
}	
stanzae = \lyricmode {
	And our eyes at last shall see Him,
	Through His own re -- deem -- ing love,
	For that Child so dear and gen -- tle
	Is our Lord in heaven a -- bove;
	And He leads His child -- ren on
	To the place where He is gone.
}
stanzaf = \lyricmode {
	Not in that poor low -- ly sta -- ble,
	With the ox -- en stand -- ing by,
	We shall see Him; but in hea -- ven,
	Set at God's right hand on high;
	When like stars His child -- ren crowned
	All in white shall wait a -- round.
}

\score {	%\transpose d c
	   \context ChoirStaff <<
	       \context ChordNames \accomp
		 \unset ChoirStaff.melismaBusyProperties 
		\context Staff ="upper"  { \clef "G" <<
			\global
			\sop
			\alto
		>>}
       		
		\lyricsto "sop" \context Lyrics = "stanza-1" {
			\set stanza = "1."
				\stanzaa }
		\lyricsto "sop" \context Lyrics = "stanza-2" {
			\set stanza = "2."
				\stanzab }
		\lyricsto "sop" \context Lyrics = "stanza-3" {
			\set stanza = "3."
				\stanzac }
		\lyricsto "sop" \context Lyrics = "stanza-4" {
			\set stanza = "4."
				\stanzad }
		\lyricsto "sop" \context Lyrics = "stanza-5" {
			\set stanza = "5."
				\stanzae }
		\lyricsto "sop" \context Lyrics = "stanza-6" {
			\set stanza = "6."
				\stanzaf }
		\context Staff = "lower"  { \clef "F"<<
			\global
			\tenor
			\bass
		>>}
	>>
	\layout{
		indent = 0.0\pt
		\context {
			\ChordNames
			\override ChordName  #'style = #'american
			chordChanges = ##t
		    }
	}
	
  \midi {
    \context {
      \Score
      tempoWholesPerMinute = #(ly:make-moment 96 4)
      }
    }


}

